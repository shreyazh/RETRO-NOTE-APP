import './globals.css'
import { Inter } from 'next/font/google'

const inter = Inter({ subsets: ['latin'] })

export const metadata = {
  title: 'Retro Note App',
  description: 'A retro-style note-taking app with to-do list and workout tracking',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <div className="retro-container">
          {children}
        </div>
      </body>
    </html>
  )
}

