'use client'

import { useState, useEffect } from 'react'

interface Exercise {
  id: number
  name: string
  sets: number
  reps: number
  weight: number
}

interface Workout {
  id: number
  date: string
  exercises: Exercise[]
}

export default function WorkoutLogger() {
  const [workouts, setWorkouts] = useState<Workout[]>([])
  const [currentWorkout, setCurrentWorkout] = useState<Exercise[]>([])
  const [exerciseName, setExerciseName] = useState('')
  const [sets, setSets] = useState('')
  const [reps, setReps] = useState('')
  const [weight, setWeight] = useState('')

  useEffect(() => {
    const savedWorkouts = localStorage.getItem('workouts')
    if (savedWorkouts) {
      setWorkouts(JSON.parse(savedWorkouts))
    }
  }, [])

  useEffect(() => {
    localStorage.setItem('workouts', JSON.stringify(workouts))
  }, [workouts])

  const addExercise = () => {
    if (exerciseName && sets && reps && weight) {
      const newExercise: Exercise = {
        id: Date.now(),
        name: exerciseName,
        sets: parseInt(sets),
        reps: parseInt(reps),
        weight: parseFloat(weight)
      }
      setCurrentWorkout([...currentWorkout, newExercise])
      setExerciseName('')
      setSets('')
      setReps('')
      setWeight('')
    }
  }

  const saveWorkout = () => {
    if (currentWorkout.length > 0) {
      const newWorkout: Workout = {
        id: Date.now(),
        date: new Date().toISOString().split('T')[0],
        exercises: currentWorkout
      }
      setWorkouts([...workouts, newWorkout])
      setCurrentWorksetCurrentWork
out([])
    }
  }

  const deleteExercise = (id: number) => {
    setCurrentWorkout(currentWorkout.filter(exercise => exercise.id !== id))
  }

  return (
    <div>
      <h2>Workout Logger</h2>
      <div>
        <input
          type="text"
          placeholder="Exercise name"
          value={exerciseName}
          onChange={(e) => setExerciseName(e.target.value)}
          className="retro-input"
        />
        <input
          type="number"
          placeholder="Sets"
          value={sets}
          onChange={(e) => setSets(e.target.value)}
          className="retro-input"
        />
        <input
          type="number"
          placeholder="Reps"
          value={reps}
          onChange={(e) => setReps(e.target.value)}
          className="retro-input"
        />
        <input
          type="number"
          placeholder="Weight"
          value={weight}
          onChange={(e) => setWeight(e.target.value)}
          className="retro-input"
        />
        <button onClick={addExercise} className="retro-button">Add Exercise</button>
      </div>
      <ul className="retro-list">
        {currentWorkout.map(exercise => (
          <li key={exercise.id}>
            {exercise.name} - {exercise.sets} sets x {exercise.reps} reps @ {exercise.weight} lbs
            <button onClick={() => deleteExercise(exercise.id)} className="retro-button">Delete</button>
          </li>
        ))}
      </ul>
      <button onClick={saveWorkout} className="retro-button">Save Workout</button>
      <h3>Previous Workouts</h3>
      <ul className="retro-list">
        {workouts.map(workout => (
          <li key={workout.id}>
            <h4>{workout.date}</h4>
            <ul>
              {workout.exercises.map(exercise => (
                <li key={exercise.id}>
                  {exercise.name} - {exercise.sets} sets x {exercise.reps} reps @ {exercise.weight} lbs
                </li>
              ))}
            </ul>
          </li>
        ))}
      </ul>
    </div>
  )
}

