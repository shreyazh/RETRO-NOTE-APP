'use client'

import { useState, useEffect } from 'react'

interface Note {
  id: number
  title: string
  content: string
}

export default function Notes() {
  const [notes, setNotes] = useState<Note[]>([])
  const [title, setTitle] = useState('')
  const [content, setContent] = useState('')
  const [editingId, setEditingId] = useState<number | null>(null)

  useEffect(() => {
    const savedNotes = localStorage.getItem('notes')
    if (savedNotes) {
      setNotes(JSON.parse(savedNotes))
    }
  }, [])

  useEffect(() => {
    localStorage.setItem('notes', JSON.stringify(notes))
  }, [notes])

  const addNote = () => {
    if (title && content) {
      const newNote = { id: Date.now(), title, content }
      setNotes([...notes, newNote])
      setTitle('')
      setContent('')
    }
  }

  const editNote = (id: number) => {
    const noteToEdit = notes.find(note => note.id === id)
    if (noteToEdit) {
      setTitle(noteToEdit.title)
      setContent(noteToEdit.content)
      setEditingId(id)
    }
  }

  const updateNote = () => {
    if (editingId && title && content) {
      setNotes(notes.map(note => 
        note.id === editingId ? { ...note, title, content } : note
      ))
      setTitle('')
      setContent('')
      setEditingId(null)
    }
  }

  const deleteNote = (id: number) => {
    setNotes(notes.filter(note => note.id !== id))
  }

  return (
    <div>
      <h2>Notes</h2>
      <input
        type="text"
        placeholder="Title"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        className="retro-input"
      />
      <textarea
        placeholder="Content"
        value={content}
        onChange={(e) => setContent(e.target.value)}
        className="retro-textarea"
      ></textarea>
      {editingId ? (
        <button onClick={updateNote} className="retro-button">Update Note</button>
      ) : (
        <button onClick={addNote} className="retro-button">Add Note</button>
      )}
      <ul className="retro-list">
        {notes.map(note => (
          <li key={note.id}>
            <h3>{note.title}</h3>
            <p>{note.content}</p>
            <button onClick={() => editNote(note.id)} className="retro-button">Edit</button>
            <button onClick={() => deleteNote(note.id)} className="retro-button">Delete</button>
          </li>
        ))}
      </ul>
    </div>
  )
}

