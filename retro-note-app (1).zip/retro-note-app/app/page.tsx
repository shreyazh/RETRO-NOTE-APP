'use client'

import { useState, useEffect } from 'react'
import Notes from './components/Notes'
import TodoList from './components/TodoList'
import WorkoutLogger from './components/WorkoutLogger'
import { saveToIndexedDB, getFromIndexedDB } from './utils/offlineStorage'

export default function Home() {
  const [activeTab, setActiveTab] = useState('notes')
  const [isOnline, setIsOnline] = useState(true)

  useEffect(() => {
    const handleOnline = () => setIsOnline(true)
    const handleOffline = () => setIsOnline(false)

    window.addEventListener('online', handleOnline)
    window.addEventListener('offline', handleOffline)

    return () => {
      window.removeEventListener('online', handleOnline)
      window.removeEventListener('offline', handleOffline)
    }
  }, [])

  useEffect(() => {
    if (isOnline) {
      // Sync data from IndexedDB to localStorage when coming back online
      getFromIndexedDB('appData').then((data) => {
        if (data) {
          Object.keys(data).forEach((key) => {
            localStorage.setItem(key, JSON.stringify(data[key]))
          })
        }
      }).catch(error => console.error('Error retrieving data:', error))
    }
  }, [isOnline])

  const saveDataForOffline = async () => {
    try {
      const appData = {
        notes: JSON.parse(localStorage.getItem('notes') || '[]'),
        todos: JSON.parse(localStorage.getItem('todos') || '[]'),
        workouts: JSON.parse(localStorage.getItem('workouts') || '[]')
      }
      await saveToIndexedDB('appData', appData)
      alert('Data saved for offline use')
    } catch (error) {
      console.error('Error saving data for offline use:', error)
      alert('Failed to save data for offline use')
    }
  }

  return (
    <div>
      <header className="retro-header">
        <h1>Retro Note App</h1>
      </header>
      <nav className="retro-nav">
        <button onClick={() => setActiveTab('notes')}>Notes</button>
        <button onClick={() => setActiveTab('todos')}>To-Do List</button>
        <button onClick={() => setActiveTab('workouts')}>Workout Logger</button>
        <button onClick={saveDataForOffline} className="retro-button">
          {isOnline ? 'Save for Offline' : 'Offline Mode'}
        </button>
      </nav>
      <main className="retro-content crt-effect">
        {activeTab === 'notes' && <Notes />}
        {activeTab === 'todos' && <TodoList />}
        {activeTab === 'workouts' && <WorkoutLogger />}
      </main>
    </div>
  )
}

