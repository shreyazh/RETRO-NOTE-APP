let db: IDBDatabase | null = null;

function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (db) {
      resolve(db);
      return;
    }

    const request = indexedDB.open('RetroNoteApp', 1);

    request.onerror = (event) => {
      reject('IndexedDB error: ' + (event.target as IDBOpenDBRequest).error);
    };

    request.onsuccess = (event) => {
      db = (event.target as IDBOpenDBRequest).result;
      resolve(db);
    };

    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains('appData')) {
        db.createObjectStore('appData', { keyPath: 'key' });
      }
    };
  });
}

export async function saveToIndexedDB(key: string, data: any): Promise<void> {
  try {
    const db = await openDB();
    const transaction = db.transaction(['appData'], 'readwrite');
    const store = transaction.objectStore('appData');
    await new Promise<void>((resolve, reject) => {
      const request = store.put({ key, data });
      request.onerror = () => reject(request.error);
      request.onsuccess = () => resolve();
    });
  } catch (error) {
    console.error('Error saving data to IndexedDB:', error);
    throw error;
  }
}

export async function getFromIndexedDB(key: string): Promise<any> {
  try {
    const db = await openDB();
    const transaction = db.transaction(['appData'], 'readonly');
    const store = transaction.objectStore('appData');
    return new Promise((resolve, reject) => {
      const request = store.get(key);
      request.onerror = () => reject(request.error);
      request.onsuccess = () => resolve(request.result ? request.result.data : null);
    });
  } catch (error) {
    console.error('Error retrieving data from IndexedDB:', error);
    throw error;
  }
}

